#include<stdio.h>
#include<stdlib.h>
#define OK 1;

struct student //�������
{ 
	int num; //ѧ��
    int score; //����
    struct student *next; //���ָ����
}*head; 

void print(struct student *head)  //(6)
{
	struct student *p=head;
    do
	{
        printf("%d    %d\n",p->num,p->score);
		p=p->next;
	}while(p!=NULL);
	printf("\n");
}

struct student *creat(void)  //(1)
{
	struct student *a,*b,*c,*d,*e,*f;
	a=(struct student*)malloc(sizeof(struct student));
	b=(struct student*)malloc(sizeof(struct student));
	c=(struct student*)malloc(sizeof(struct student));
	d=(struct student*)malloc(sizeof(struct student));
	e=(struct student*)malloc(sizeof(struct student));
	f=(struct student*)malloc(sizeof(struct student));
	a->num=10101;	a->score=89;
	b->num=10102;	b->score=98;
	c->num=10103;	c->score=92;
	d->num=10104;	d->score=59;
	e->num=10105;	e->score=67;
	f->num=10106;	f->score=83;
	head=a;	a->next=b;  b->next=c;  c->next=d;
	d->next=e; e->next=f; f->next=NULL;
	return head;
}

struct student *insert(struct student *head) //(2)
{
	struct student *p=head;
	struct student *g;
	g=(struct student*)malloc(sizeof(struct student));
    do
	{
        p=p->next;
	}
	while(p->next!=NULL);
	g->num=10107;    g->score=91;
	p->next=g;       g->next=NULL;
	return head;
}

struct student *del(struct student *head,int key) //(3)
{
	struct student *p=head;
    int flag=0;
	if(p->num==key)
	{
		head=p->next;
		free(p);
		flag=1;
	}
    else
	{
		do
		{
            if(p->next->num==key)
			{
                p->next=p->next->next;
				flag=1;
				break;
			}
			p=p->next;
		}
	    while(p->next!=NULL);    
	}
	if(flag)
		return head;
	else
		return NULL;
 }

int sum(struct student *head)//(4)
{
    int sum=0;
	struct student *p=head;
	do
	{
        sum+=p->score;
		p=p->next;
	}
	while(p!=NULL);
	return sum;
}

void find(struct student *head)//(5)
{
    struct student *p=head,*q=p;
	int max_score=p->score;
	do
	{
        if(p->score>max_score)
		{
			q=p;
			max_score=p->score;
		}
		p=p->next;
	}
	while(p!=NULL);
	printf("5:the maximun student's key is %d, his score is %d\n\n",q->num,q->score);
}

void main()
{
	head=creat();//(1)
	printf("1:\n");
	print(head);

	insert(head);//(2)
	printf("2:\n");
	print(head);

	del(head,10103);//(3)
	printf("3:\n");
	print(head);

	printf("4:the sum is %d\n\n",sum(head));//(4)

	find(head);//(5)

	printf("6:it's incorporated in the former\n\n");//(6)
}
