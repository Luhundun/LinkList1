#include<stdio.h>
#include<stdlib.h>
#include<time.h>
int func(int *p)
{
    int i,sum=0,aver,num=0;
	for(i=0;i<30;i++)
	{
		sum+=*(p+i);
	}
	aver=sum/30;
	for(i=0;i<30;i++)
	{
		if(*(p+i)>aver) num++;
	}
	return num;
}
void main()
{
	int a[30],i,n;
	srand((unsigned)time(NULL));
	for(i=0;i<30;i++)
	{
        a[i]=rand()%41+59;
		printf("%3d",a[i]);
	}
    n=func(a);
	printf("\n����ƽ���ֵ���%d��\n",n);
}