#include<stdio.h>
void swap(int *x,int *y)
{
    int temp;
	temp=*x;*x=*y;*y=temp;
}
void main()
{
	int x,y;
	int *p=&x,*q=&y;
	printf("Please enter x,y:");
	scanf("%d%d",&x,&y);
	swap(p,q);
	printf("After swap:x=%d y=%d",x,y);
}