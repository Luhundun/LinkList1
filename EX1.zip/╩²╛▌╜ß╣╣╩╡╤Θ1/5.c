#include<stdio.h>
#include<stdlib.h>
#include<time.h>
#define N 10
int find_max(int p[],int n)
{
	int i,temp_max=p[0],k=0;
	for(i=0;i<n;i++)
	{
		if(temp_max<p[i])
		{
			k=i;
			temp_max=p[i];
		}
	}
	return k;
}
void main()
{
    int p[N]={0},i;
	srand((unsigned)time(NULL));
	printf("the array is:");
	for(i=0;i<N;i++)
	{
		p[i]=rand()%100+1;
		printf("%3d ",p[i]);
	}
	printf("\nThe subscript of the maximun value is %d\n",find_max(p,N));
}