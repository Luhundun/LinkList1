#include<stdio.h>
#include<stdlib.h>
#define listinitsize 100
#define listincrement 10
typedef int ElemType;  //˳����д�ŵ�������       
typedef struct 
{
    ElemType *elem;        //�洢�ռ��ַ                                     
    int length;             //��ǰ����                                     
    int listsize;           //��ǰ����Ĵ洢����
}SqList;


void PrintList(SqList L)     // ���˳���
{
	for(int i=0;i<L.length;i++)
	{
        printf("%d   ",L.elem[i]);
	}
	printf("\n");
}

void InitListA(SqList  &L, int n)   
{
	L.elem=(ElemType*)malloc(listinitsize*sizeof(ElemType));
	if(!L.elem) exit(-2);
	L.length=n;
	L.listsize=listinitsize;
	for(int i=0;i<n;i++)             //����˳���A
	{
		*(L.elem+i)=1+5*i;
	}
	PrintList(L);
}

void InitListB(SqList  &L, int n)   
{
	L.elem=(ElemType*)malloc(listinitsize*sizeof(ElemType));
	if(!L.elem) exit(-2);
	L.length=n;
	L.listsize=listinitsize;
	for(int i=0;i<n;i++)             //����˳���B
	{
		*(L.elem+i)=1+10*i;
	}
	PrintList(L);
}

void CompareList(SqList A,SqList B)
{
	ElemType *p=A.elem,*q=B.elem;
	while(*p++==*q++) {};
    if(*p>*q||q==NULL)
		printf("A > B\n");
	else
	    printf("A < B\n");
}

void main()
{
    SqList A,B,C;
	printf("A:");InitListA(A,20);
	printf("B:");InitListB(B,10);
	CompareList(A,B);
}