#include<stdio.h>
#include<stdlib.h>
#include<time.h>
#define listinitsize 100
#define listincrement 10
typedef int ElemType;  //˳����д�ŵ�������       
typedef struct 
{
    ElemType *elem;        //�洢�ռ��ַ                                     
    int length;             //��ǰ����                                     
    int listsize;           //��ǰ����Ĵ洢����
}SqList;


void PrintList(SqList L)     // ���˳���
{
	for(int i=0;i<L.length;i++)
	{
        printf("%d   ",L.elem[i]);
	}
	printf("\n");
}

void InitList(SqList  &L, int n)   //����һ������Ϊn��˳���
{
	L.elem=(ElemType*)malloc(listinitsize*sizeof(ElemType));
	if(!L.elem) exit(-2);
	L.length=n;
	L.listsize=listinitsize;
	for(int i=0,k=0;i<n;i++)             //����һ����һ�޶��ĵ�����Ԫ�ػ����ظ���˳���
	{
		*(L.elem+i)=k;
		if(rand()%3==1) k++;
		if(rand()%4==1) k+=2;
		if(rand()%9==1) k+=3;
		if(rand()%15==1) k+=5;
	}
	for( i=0;i<L.length;i++)
	{
		while(L.elem[i]==L.elem[i+1])
		{
			 for(int k=i+1;k<L.length;k++)
			 {
			     L.elem[k]=L.elem[k+1];
			 }
			 L.length--;
		}
	}
	PrintList(L);
}

SqList CombineList(SqList A,SqList B)
{
	SqList C;
	C.elem=(ElemType *)malloc(listinitsize*sizeof(ElemType));
	if(!C.elem) exit(-2);
	C.length=0;
	C.listsize=listinitsize;
	for(int i=0,j=0,k=0;i<A.length||j<B.length; )
	{
		if(A.elem[i]>B.elem[j]&&i<A.length&&j<B.length||i==A.length)
		{
            C.elem[k++]=B.elem[j++];
			C.length++;
		}
		else if(A.elem[i]==B.elem[j]&&i<A.length&&j<B.length)
		{
			C.elem[k++]=A.elem[i++];
			C.length++;
			j++;
		}
		else 
		{
			C.elem[k++]=A.elem[i++];
			C.length++;
		}
	}
	return C;
}

void main()
{
	srand((unsigned)time(NULL));
    SqList A,B,C;
	printf("A:");InitList(A,30);
	printf("B:");InitList(B,30);
	C=CombineList(A,B);
	printf("C:");PrintList(C);
}