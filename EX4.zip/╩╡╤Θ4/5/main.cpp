#include"Calculate.h"
#include"Stack.h"


void main()
{
	printf ("\n���Ϊ%d\n",Evaluate_Expression());
}