#include<stdio.h>

void move(char a,char b)
{
	printf("move %c-->%c\n",a,b);
}

void hannoi(int n,char a,char b,char c)
{
	if(n==1)
	{
		move(a,c);
	}
	else{
		hannoi(n-1,a,c,b);
	    move(a,c);
	    hannoi(n-1,b,a,c);
	}
}

void main()
{
	int N;
	printf("������Բ������");
	scanf("%d",&N);
	hannoi(N,'a','b','c');
}