#include "SQ.h"


void InitStack(SqStack &S)
{
    S.base=(ElemType *)malloc(STACKINITSIZE*sizeof(ElemType));
	if(!S.base) exit(-2);
	S.top=S.base;
	S.stacksize=STACKINITSIZE;
}//��ʼ��ջ

void Push(SqStack &S,ElemType e)
{
	if(S.top-S.base>=S.stacksize)
	{
		S.base=(ElemType *)realloc(S.base,(S.stacksize+STACKINCREMENT)*(sizeof(ElemType)));
	    if(!S.base) exit(-2);
	    S.top=S.base+S.stacksize;
		S.stacksize+=STACKINCREMENT;
	}
	*S.top++=e;
}//��ջ

void Pop(SqStack &S,ElemType &e)
{ 
    if(S.top==S.base) printf("����!\n");
	else
	{
		e=*--S.top;
	}
}//��ջ

void GetTop(SqStack S,ElemType e)
{
	e=*(S.top-1);
}//ȡջ��Ԫ��

int StackEmpty(SqStack S)
{
	if(S.base==S.top)
		return 1;
	else return 0;
}//�ж��Ƿ�Ϊ��ջ

int LenStack(SqStack S)//��ջ��
{
    return S.top-S.base;
}
void VisitStack(SqStack S)
{
	while(S.base!=S.top)
	{
		printf("| %3d  %3d |",(S.top-1)->num,(S.top-1)->time);
		S.top--;
	}
}//����ջ

void InitQueue(LinkQueue &Q)//��ʼ������
{
    Q.front=Q.rear=(Queueptr)malloc(sizeof(QNode));
	if(!Q.front) exit(-2);
	Q.front->next=NULL;
}

void EnQueue(LinkQueue &Q,ElemType e)//�����
{
    Queueptr p;
    p=(Queueptr)malloc(sizeof(QNode));
	if(!p) exit(-2);
	p->data=e;
	p->next=NULL;
	Q.rear->next=p;
	Q.rear=p;
}

void DeQueue(LinkQueue &Q,ElemType &e)//������
{
	Queueptr p;
    if(Q.front==Q.rear) {printf("ERROR"); exit(-2);}
	p=Q.front->next;
	e=p->data;
	Q.front->next=p->next;
    if(Q.rear==p) Q.rear=Q.front;
	free(p);
}

void GetHead(LinkQueue &Q,ElemType e)//ȡ��ͷԪ��
{
	if(Q.front==Q.rear) exit(-2);
	e=Q.front->next->data;
}

void PrintQueue(LinkQueue Q)//������
{
	Queueptr p;
	p=Q.front->next;
	while(p)
	{
		printf("%d   ",p->data.num);
		p=p->next;
	}
}

int LenQueue(LinkQueue Q)//��ӳ�
{
	Queueptr p;
	int len=0;
	p=Q.front->next;
	while(p)
	{
        len++;
		p=p->next;
	}
	return len;
}

void DestoryQueue(LinkQueue &Q)//�ݻٶ���
{
	while(Q.front)
	{
		Q.rear=Q.front->next;
		free(Q.front);
		Q.front=Q.rear;
	}
}
