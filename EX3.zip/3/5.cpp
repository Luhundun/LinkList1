#include<stdio.h>
#include<stdlib.h>

typedef struct
{
	float coef;
	int expn;
}term,ElemType;

typedef struct LNode                    
{  
    ElemType data;   //   
    struct LNode *next;                    
}LNode,*LinkList; 

typedef LinkList polynomial;


void PPrint(polynomial l)//��ʾ����ʽ
{
	polynomial p=l->next;
	while(p)
	{
		if(p->data.coef==0)   //����
		{
			p=p->next;
		}
		else if(p->data.coef==1&&p->data.expn!=0)
		{
			printf("+x^%d ",p->data.expn);
	    	p=p->next;
		}
		else if(p->data.expn==0)
		{
			printf("+%.2f ",p->data.coef);
	    	p=p->next;
		}
		else if(p->data.expn==1)
		{
			printf("+%.2fx ",p->data.coef);
	    	p=p->next;
		}
		else
		{
			printf("+%.2f",p->data.coef);
			printf("x^%d",p->data.expn);
			p=p->next;
		}	
	}
	printf("\n");
}

void CreatPa(polynomial &l)//����polynomial La��
{
    polynomial p,r;
	l=(polynomial)malloc(sizeof(LNode)); 
	r=l;
	p=(polynomial)malloc(sizeof(LNode));
	p->data.coef=7;p->data.expn=0;r->next=p;r=p;
	p=(polynomial)malloc(sizeof(LNode));
	p->data.coef=3;p->data.expn=1;r->next=p;r=p;
	p=(polynomial)malloc(sizeof(LNode));
	p->data.coef=5;p->data.expn=4;r->next=p;r=p;
	p=(polynomial)malloc(sizeof(LNode));
	p->data.coef=9;p->data.expn=8;r->next=p;r=p;
	p=(polynomial)malloc(sizeof(LNode));
	p->data.coef=5;p->data.expn=17;r->next=p;p->next=NULL;
}

void CreatPb(polynomial &l)//����polynomial Lb��
{
    polynomial p,r;
	l=(polynomial)malloc(sizeof(LNode)); 
	r=l;
	p=(polynomial)malloc(sizeof(LNode));
	p->data.coef=8;p->data.expn=1;r->next=p;r=p;
	p=(polynomial)malloc(sizeof(LNode));
	p->data.coef=22;p->data.expn=7;r->next=p;r=p;
	p=(polynomial)malloc(sizeof(LNode));
	p->data.coef=-9;p->data.expn=8;r->next=p;p->next=NULL;
}

void AddPolynomial(polynomial &a,polynomial b)
{
	polynomial pa=a->next,pb=b->next,p;
	while(pa&&pb)
	{
        if(pa->data.expn<pb->data.expn)
		{
            pa=pa->next;
		}
		else if(pa->data.expn==pb->data.expn)
		{
			pa->data.coef=pa->data.coef+pb->data.coef;
			pa=pa->next;
			pb=pb->next;
		}
		else if(pa->data.expn>pb->data.expn)
		{
			p=(polynomial)malloc(sizeof(LNode));
        	p->data.coef=pb->data.coef;
			p->data.expn=pb->data.expn;
			p->next=pa->next;
			pa->next=p;
			pb=pb->next;
		}
	}
	if(pb)
	{
		pa=pb;
	}
}

void main()
{
	polynomial La,Lb;
	CreatPa(La);
	PPrint(La);
	CreatPb(Lb); 
	PPrint(Lb);
    AddPolynomial(La,Lb);
	printf("\n��ӽ��Ϊ:");
	PPrint(La);
}
